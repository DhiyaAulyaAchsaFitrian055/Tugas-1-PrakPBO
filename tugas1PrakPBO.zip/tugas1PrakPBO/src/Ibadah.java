public interface Ibadah {
    String Sholat();
}
